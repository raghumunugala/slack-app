package com.myslack.app.model;

/**
 * Customer Data Model to persist and retrieve customer information
 */
public class CustomerDetailsModel {

    private String name;

    private String supportLevel;

    private String successManagerEmail;

    private String accountManagerEmail;

    private String programId;

    private String products;

    private String supportEngineer;

    private String serverDetail;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSupportLevel() {
        return supportLevel;
    }

    public void setSupportLevel(String supportLevel) {
        this.supportLevel = supportLevel;
    }

    public String getSuccessManagerEmail() {
        return successManagerEmail;
    }

    public void setSuccessManagerEmail(String successManagerEmail) {
        this.successManagerEmail = successManagerEmail;
    }

    public String getAccountManagerEmail() {
        return accountManagerEmail;
    }

    public void setAccountManagerEmail(String accountManagerEmail) {
        this.accountManagerEmail = accountManagerEmail;
    }

    public String getProgramId() {
        return programId;
    }

    public void setProgramId(String programId) {
        this.programId = programId;
    }

    public String getProducts() {
        return products;
    }

    public void setProducts(String products) {
        this.products = products;
    }

    public String getSupportEngineer() {
        return supportEngineer;
    }

    public void setSupportEngineer(String supportEngineer) {
        this.supportEngineer = supportEngineer;
    }

    public String getServerDetail() {
        return serverDetail;
    }

    public void setServerDetail(String serverDetail) {
        this.serverDetail = serverDetail;
    }
}
