package com.myslack.app.dao;

import com.myslack.app.model.CustomerDetailsModel;

/**
 * Data Access Service
 */
public interface DataAccessService {

    CustomerDetailsModel findCustomerDetails(String customerName);

    CustomerDetailsModel findCustomerContacts(String customerContacts);
}
