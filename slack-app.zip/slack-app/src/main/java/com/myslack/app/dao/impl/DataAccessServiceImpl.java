package com.myslack.app.dao.impl;

import com.myslack.app.dao.DataAccessService;
import com.myslack.app.model.CustomerDetailsModel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DataAccessServiceImpl implements DataAccessService {

    public Connection connect() {
        Connection connection = null;
        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "rmunugala", "");
        } catch(Exception exception) {
            exception.printStackTrace();
        } finally {
            return connection;
        }
    }

    /**
     * Retrieve all the information of customer
     * @param customerName
     * @return
     */
    @Override
    public CustomerDetailsModel findCustomerDetails(String customerName) {
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        CustomerDetailsModel customerDetailsModel = new CustomerDetailsModel();
        Connection connection = connect();
        try {
            preparedStatement = connection.prepareStatement("SELECT * FROM customerdata WHERE LOWER(customername)=?");
            preparedStatement.setString(1, customerName.toLowerCase());
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                customerDetailsModel.setName(resultSet.getString("customername"));
                customerDetailsModel.setProgramId(resultSet.getString("programid"));
                customerDetailsModel.setSupportLevel(resultSet.getString("supportlevel"));
                customerDetailsModel.setSuccessManagerEmail(resultSet.getString("csmemail"));
                customerDetailsModel.setAccountManagerEmail(resultSet.getString("tamemail"));;
                customerDetailsModel.setSupportEngineer(resultSet.getString("supportemail"));
                customerDetailsModel.setServerDetail(resultSet.getString("serverurl"));
                customerDetailsModel.setProducts(resultSet.getString("products"));
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                    resultSet.close();
                    connection.close();
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }
            return customerDetailsModel;
        }
    }

    /**
     * Retrieve contact details of customer
     * @param customerName
     * @return
     */
    @Override
    public CustomerDetailsModel findCustomerContacts(String customerName) {

        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        CustomerDetailsModel customerDetailsModel = new CustomerDetailsModel();
        Connection connection = connect();
        try {
            preparedStatement = connection.prepareStatement("SELECT customername,csmemail,tamemail,supportemail FROM customerdata WHERE LOWER(customername)=?");
            preparedStatement.setString(1, customerName.toLowerCase());
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                customerDetailsModel.setName(resultSet.getString("customername"));
                customerDetailsModel.setSuccessManagerEmail(resultSet.getString("csmemail"));
                customerDetailsModel.setAccountManagerEmail(resultSet.getString("tamemail"));;
                customerDetailsModel.setSupportEngineer(resultSet.getString("supportemail"));
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                    resultSet.close();
                    connection.close();
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }
            return customerDetailsModel;
        }
    }
}
