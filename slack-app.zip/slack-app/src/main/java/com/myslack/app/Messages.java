package com.myslack.app;

/**
 * This class is used
 */
public class Messages {

    public static String HELP_MESSAGE = "These are the available Customer Information App commands:\n" +
            "`/customerinfo [customername]` - Get the Customer Details\n\n" +
            "`/customerinfo contacts [customername]` - Get Brief Customer Details";
    public static String ERROR_MESSAGE = "Sorry, please refer to `/customerinfo help` for the command options.\n";

    public static String CONTACT_MESSAGE = "Please find below Details:\n*Customer Name:*\t{0}"+
            "\n*Success Manager:*\t{1}"+
            "\n*Technical Account Manager:*\t{2}"+
            "\n*Support Engineer:*\t{3}";

    public static String NO_CUSTOMER_MESSAGE = "Sorry, the `customer: {0}` details are not found";

    public static String CUSTOMER_DATA_MESSAGE = "Please find below Details:\n*Customer Name:*\t{0}"+
            "\n*Program Id:*\t{1}"+
            "\n*Support Level:*\t{2}"+
            "\n*Success Manager:*\t{3}"+
            "\n*Technical Account Manager:*\t{4}"+
            "\n*Products:*\t{5}"+
            "\n*Support Engineer:*\t{6}"+
            "\n*Server Details:*\t{7}";
}
