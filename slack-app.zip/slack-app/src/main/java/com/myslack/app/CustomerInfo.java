package com.myslack.app;

import com.myslack.app.dao.DataAccessService;
import com.myslack.app.dao.impl.DataAccessServiceImpl;
import com.myslack.app.model.CustomerDetailsModel;
import com.slack.api.bolt.App;
import com.slack.api.bolt.AppConfig;
import com.slack.api.bolt.context.builtin.SlashCommandContext;
import com.slack.api.bolt.jetty.SlackAppServer;
import com.slack.api.bolt.request.builtin.SlashCommandRequest;
import com.slack.api.bolt.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Properties;
import static com.myslack.app.Messages.*;

/**
 * This class is the main class which is loaded when the app is loaded
 */
public class CustomerInfo {

    /*configuration properties file name*/
    private static String CONFIG_FILE = "config.properties";
    private static String SLACK_BOT_TOKEN_KEY = "SLACK_BOT_TOKEN";
    private static String SLACK_SIGNING_SECRET_KEY = "SLACK_SIGNING_SECRET";
    private static Logger LOG = LoggerFactory.getLogger(CustomerInfo.class);

    private enum COMMAND_ARGS {
        HELP,
        CONTACTS,
        DEFAULT;
    };

    static DataAccessService dataAccessService = new DataAccessServiceImpl();;

    /**
     * Parse the app settings from configuration file
     * @return Properties
     */
    private static Properties readConfigFile() {
        Properties properties = null;
        try(InputStream inputStream = CustomerInfo.class.getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            properties = new Properties();
            properties.load(inputStream);
        }
        catch (FileNotFoundException fileNotFoundException) {
            LOG.error("Config file Not found:{}", CONFIG_FILE, fileNotFoundException);
        } finally {
            return properties;
        }
    }

    /**
     * This main method will start the jetty server to receive slash command requests
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {

        AppConfig appConfig = new AppConfig();

        Properties configProperties = readConfigFile();
        appConfig.setSingleTeamBotToken(configProperties.getProperty(SLACK_BOT_TOKEN_KEY));
        appConfig.setSigningSecret(configProperties.getProperty(SLACK_SIGNING_SECRET_KEY));
        App customerInfoApp = new App(appConfig);

        customerInfoApp.command("/customerinfo", (request, ctx) -> {
            return commandResponse(request, ctx);
        });

        SlackAppServer server = new SlackAppServer(customerInfoApp);
        server.start();
    }

    /**
     * This method builds the response for the command if the command request is not as expected an acknowledgment
     * is sent about the command usage
     * @param slashCommandRequest
     * @param slashCommandContext
     * @return Response
     */

    private static Response commandResponse(SlashCommandRequest slashCommandRequest, SlashCommandContext slashCommandContext) {
        String[] argument = null;
        String message = Messages.ERROR_MESSAGE;
        CustomerDetailsModel customerModel;
        if (slashCommandRequest.getPayload().getText() != null) {
            argument = slashCommandRequest.getPayload().getText().split(" ");
        }
        if (argument != null) {
            COMMAND_ARGS requestedCommand = getCommand(argument[0].toUpperCase());
            switch(requestedCommand) {
                case HELP:
                    message = Messages.HELP_MESSAGE;
                    break;
                case CONTACTS:
                    customerModel = dataAccessService.findCustomerContacts(argument[1]);
                    if (customerModel.getName() != null)
                        message = MessageFormat.format(Messages.CONTACT_MESSAGE, customerModel.getName(),
                                customerModel.getSuccessManagerEmail(), customerModel.getAccountManagerEmail(),
                                customerModel.getSupportEngineer());
                    else
                        message = MessageFormat.format(NO_CUSTOMER_MESSAGE, argument[1]);
                    break;
                default:
                    customerModel = dataAccessService.findCustomerDetails(argument[0]);
                    if (customerModel.getName() != null)
                        message = MessageFormat.format(CUSTOMER_DATA_MESSAGE, customerModel.getName(),
                                customerModel.getProgramId(), customerModel.getSupportLevel(),
                                customerModel.getSuccessManagerEmail(), customerModel.getAccountManagerEmail(),
                                customerModel.getProducts(), customerModel.getSupportEngineer(),
                                customerModel.getServerDetail());
                    else
                        message = MessageFormat.format(NO_CUSTOMER_MESSAGE, argument[0]);
                    break;
            }
        }
        return slashCommandContext.ack(message);
    }

    /**
     * This utility method will either return default or command type
     * @param enumString
     * @return
     */
    private static COMMAND_ARGS getCommand(String enumString) {
        try {
            return COMMAND_ARGS.valueOf(enumString);
        } catch (Exception exception) {
            return COMMAND_ARGS.DEFAULT;
        }
    }
}
